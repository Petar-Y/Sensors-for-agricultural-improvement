document.addEventListener('DOMContentLoaded', function() {
    // Simulate fetching sensor data
    let sensorData = [
        { id: 1, type: 'Temperature', value: '22°C', status: 'Active' },
        { id: 2, type: 'Humidity', value: '60%', status: 'Active' },
        { id: 3, type: 'Air Quality', value: 'Good', status: 'Inactive' }
    ];

    let sensorDataContainer = document.getElementById('sensor-data');

    sensorData.forEach(sensor => {
        let sensorDiv = document.createElement('div');
        sensorDiv.classList.add('sensor');
        sensorDiv.innerHTML = `
            <h3>Sensor ID: ${sensor.id}</h3>
            <p>Type: ${sensor.type}</p>
            <p>Value: ${sensor.value}</p>
            <p>Status: ${sensor.status}</p>
        `;
        sensorDataContainer.appendChild(sensorDiv);
    });

    // Simulate fetching alert data
    let alertData = [
        { id: 1, message: 'Temperature exceeds threshold', severity: 'High' },
        { id: 2, message: 'Humidity is below threshold', severity: 'Medium' }
    ];

    let alertDataContainer = document.getElementById('alert-list');

    alertData.forEach(alert => {
        let alertDiv = document.createElement('div');
        alertDiv.classList.add('alert');
        alertDiv.innerHTML = `
            <h3>Alert ID: ${alert.id}</h3>
            <p>Message: ${alert.message}</p>
            <p>Severity: ${alert.severity}</p>
        `;
        alertDataContainer.appendChild(alertDiv);
    });
});
