export class ValidationError extends Error {
    readonly name = "ValidationError";
    readonly stack = (new Error()).stack;

    constructor(message: string) {
        super(message);
    }
}