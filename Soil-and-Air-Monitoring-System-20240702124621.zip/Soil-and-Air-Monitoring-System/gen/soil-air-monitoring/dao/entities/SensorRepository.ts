import { query } from "sdk/db";
import { producer } from "sdk/messaging";
import { extensions } from "sdk/extensions";
import { dao as daoApi } from "sdk/db";

export interface SensorEntity {
    readonly SensorId: number;
    Name?: string;
    Type?: string;
    MeasurementId?: number;
}

export interface SensorCreateEntity {
    readonly Name?: string;
    readonly Type?: string;
    readonly MeasurementId?: number;
}

export interface SensorUpdateEntity extends SensorCreateEntity {
    readonly SensorId: number;
}

export interface SensorEntityOptions {
    $filter?: {
        equals?: {
            SensorId?: number | number[];
            Name?: string | string[];
            Type?: string | string[];
            MeasurementId?: number | number[];
        };
        notEquals?: {
            SensorId?: number | number[];
            Name?: string | string[];
            Type?: string | string[];
            MeasurementId?: number | number[];
        };
        contains?: {
            SensorId?: number;
            Name?: string;
            Type?: string;
            MeasurementId?: number;
        };
        greaterThan?: {
            SensorId?: number;
            Name?: string;
            Type?: string;
            MeasurementId?: number;
        };
        greaterThanOrEqual?: {
            SensorId?: number;
            Name?: string;
            Type?: string;
            MeasurementId?: number;
        };
        lessThan?: {
            SensorId?: number;
            Name?: string;
            Type?: string;
            MeasurementId?: number;
        };
        lessThanOrEqual?: {
            SensorId?: number;
            Name?: string;
            Type?: string;
            MeasurementId?: number;
        };
    },
    $select?: (keyof SensorEntity)[],
    $sort?: string | (keyof SensorEntity)[],
    $order?: 'asc' | 'desc',
    $offset?: number,
    $limit?: number,
}

interface SensorEntityEvent {
    readonly operation: 'create' | 'update' | 'delete';
    readonly table: string;
    readonly entity: Partial<SensorEntity>;
    readonly key: {
        name: string;
        column: string;
        value: number;
    }
}

interface SensorUpdateEntityEvent extends SensorEntityEvent {
    readonly previousEntity: SensorEntity;
}

export class SensorRepository {

    private static readonly DEFINITION = {
        table: "SENSOR",
        properties: [
            {
                name: "SensorId",
                column: "SENSOR_SENSORID",
                type: "INTEGER",
                id: true,
                autoIncrement: true,
            },
            {
                name: "Name",
                column: "SENSOR_NAME",
                type: "VARCHAR",
            },
            {
                name: "Type",
                column: "SENSOR_TYPE",
                type: "VARCHAR",
            },
            {
                name: "MeasurementId",
                column: "SENSOR_MEASUREMENT",
                type: "INTEGER",
            }
        ]
    };

    private readonly dao;

    constructor(dataSource = "DefaultDB") {
        this.dao = daoApi.create(SensorRepository.DEFINITION, null, dataSource);
    }

    public findAll(options?: SensorEntityOptions): SensorEntity[] {
        return this.dao.list(options);
    }

    public findById(id: number): SensorEntity | undefined {
        const entity = this.dao.find(id);
        return entity ?? undefined;
    }

    public create(entity: SensorCreateEntity): number {
        const id = this.dao.insert(entity);
        this.triggerEvent({
            operation: "create",
            table: "SENSOR",
            entity: entity,
            key: {
                name: "SensorId",
                column: "SENSOR_SENSORID",
                value: id
            }
        });
        return id;
    }

    public update(entity: SensorUpdateEntity): void {
        const previousEntity = this.findById(entity.Id);
        this.dao.update(entity);
        this.triggerEvent({
            operation: "update",
            table: "SENSOR",
            entity: entity,
            previousEntity: previousEntity,
            key: {
                name: "SensorId",
                column: "SENSOR_SENSORID",
                value: entity.SensorId
            }
        });
    }

    public upsert(entity: SensorCreateEntity | SensorUpdateEntity): number {
        const id = (entity as SensorUpdateEntity).SensorId;
        if (!id) {
            return this.create(entity);
        }

        const existingEntity = this.findById(id);
        if (existingEntity) {
            this.update(entity as SensorUpdateEntity);
            return id;
        } else {
            return this.create(entity);
        }
    }

    public deleteById(id: number): void {
        const entity = this.dao.find(id);
        this.dao.remove(id);
        this.triggerEvent({
            operation: "delete",
            table: "SENSOR",
            entity: entity,
            key: {
                name: "SensorId",
                column: "SENSOR_SENSORID",
                value: id
            }
        });
    }

    public count(options?: SensorEntityOptions): number {
        return this.dao.count(options);
    }

    public customDataCount(): number {
        const resultSet = query.execute('SELECT COUNT(*) AS COUNT FROM "SENSOR"');
        if (resultSet !== null && resultSet[0] !== null) {
            if (resultSet[0].COUNT !== undefined && resultSet[0].COUNT !== null) {
                return resultSet[0].COUNT;
            } else if (resultSet[0].count !== undefined && resultSet[0].count !== null) {
                return resultSet[0].count;
            }
        }
        return 0;
    }

    private async triggerEvent(data: SensorEntityEvent | SensorUpdateEntityEvent) {
        const triggerExtensions = await extensions.loadExtensionModules("Soil-and-Air-Monitoring-System-entities-Sensor", ["trigger"]);
        triggerExtensions.forEach(triggerExtension => {
            try {
                triggerExtension.trigger(data);
            } catch (error) {
                console.error(error);
            }            
        });
        producer.topic("Soil-and-Air-Monitoring-System-entities-Sensor").send(JSON.stringify(data));
    }
}
