import { query } from "sdk/db";
import { producer } from "sdk/messaging";
import { extensions } from "sdk/extensions";
import { dao as daoApi } from "sdk/db";

export interface LocationEntity {
    readonly LocationId: number;
    Name?: string;
    Latitude?: number;
    Longitude?: number;
    MeasurementId?: number;
}

export interface LocationCreateEntity {
    readonly Name?: string;
    readonly Latitude?: number;
    readonly Longitude?: number;
    readonly MeasurementId?: number;
}

export interface LocationUpdateEntity extends LocationCreateEntity {
    readonly LocationId: number;
}

export interface LocationEntityOptions {
    $filter?: {
        equals?: {
            LocationId?: number | number[];
            Name?: string | string[];
            Latitude?: number | number[];
            Longitude?: number | number[];
            MeasurementId?: number | number[];
        };
        notEquals?: {
            LocationId?: number | number[];
            Name?: string | string[];
            Latitude?: number | number[];
            Longitude?: number | number[];
            MeasurementId?: number | number[];
        };
        contains?: {
            LocationId?: number;
            Name?: string;
            Latitude?: number;
            Longitude?: number;
            MeasurementId?: number;
        };
        greaterThan?: {
            LocationId?: number;
            Name?: string;
            Latitude?: number;
            Longitude?: number;
            MeasurementId?: number;
        };
        greaterThanOrEqual?: {
            LocationId?: number;
            Name?: string;
            Latitude?: number;
            Longitude?: number;
            MeasurementId?: number;
        };
        lessThan?: {
            LocationId?: number;
            Name?: string;
            Latitude?: number;
            Longitude?: number;
            MeasurementId?: number;
        };
        lessThanOrEqual?: {
            LocationId?: number;
            Name?: string;
            Latitude?: number;
            Longitude?: number;
            MeasurementId?: number;
        };
    },
    $select?: (keyof LocationEntity)[],
    $sort?: string | (keyof LocationEntity)[],
    $order?: 'asc' | 'desc',
    $offset?: number,
    $limit?: number,
}

interface LocationEntityEvent {
    readonly operation: 'create' | 'update' | 'delete';
    readonly table: string;
    readonly entity: Partial<LocationEntity>;
    readonly key: {
        name: string;
        column: string;
        value: number;
    }
}

interface LocationUpdateEntityEvent extends LocationEntityEvent {
    readonly previousEntity: LocationEntity;
}

export class LocationRepository {

    private static readonly DEFINITION = {
        table: "LOCATION",
        properties: [
            {
                name: "LocationId",
                column: "LOCATION_LOCATIONID",
                type: "INTEGER",
                id: true,
                autoIncrement: true,
            },
            {
                name: "Name",
                column: "LOCATION_NAME",
                type: "VARCHAR",
            },
            {
                name: "Latitude",
                column: "LOCATION_PROPERTY3",
                type: "DECIMAL",
            },
            {
                name: "Longitude",
                column: "LOCATION_LONGITUDE",
                type: "DECIMAL",
            },
            {
                name: "MeasurementId",
                column: "LOCATION_MEASUREMENT",
                type: "INTEGER",
            }
        ]
    };

    private readonly dao;

    constructor(dataSource = "DefaultDB") {
        this.dao = daoApi.create(LocationRepository.DEFINITION, null, dataSource);
    }

    public findAll(options?: LocationEntityOptions): LocationEntity[] {
        return this.dao.list(options);
    }

    public findById(id: number): LocationEntity | undefined {
        const entity = this.dao.find(id);
        return entity ?? undefined;
    }

    public create(entity: LocationCreateEntity): number {
        const id = this.dao.insert(entity);
        this.triggerEvent({
            operation: "create",
            table: "LOCATION",
            entity: entity,
            key: {
                name: "LocationId",
                column: "LOCATION_LOCATIONID",
                value: id
            }
        });
        return id;
    }

    public update(entity: LocationUpdateEntity): void {
        const previousEntity = this.findById(entity.Id);
        this.dao.update(entity);
        this.triggerEvent({
            operation: "update",
            table: "LOCATION",
            entity: entity,
            previousEntity: previousEntity,
            key: {
                name: "LocationId",
                column: "LOCATION_LOCATIONID",
                value: entity.LocationId
            }
        });
    }

    public upsert(entity: LocationCreateEntity | LocationUpdateEntity): number {
        const id = (entity as LocationUpdateEntity).LocationId;
        if (!id) {
            return this.create(entity);
        }

        const existingEntity = this.findById(id);
        if (existingEntity) {
            this.update(entity as LocationUpdateEntity);
            return id;
        } else {
            return this.create(entity);
        }
    }

    public deleteById(id: number): void {
        const entity = this.dao.find(id);
        this.dao.remove(id);
        this.triggerEvent({
            operation: "delete",
            table: "LOCATION",
            entity: entity,
            key: {
                name: "LocationId",
                column: "LOCATION_LOCATIONID",
                value: id
            }
        });
    }

    public count(options?: LocationEntityOptions): number {
        return this.dao.count(options);
    }

    public customDataCount(): number {
        const resultSet = query.execute('SELECT COUNT(*) AS COUNT FROM "LOCATION"');
        if (resultSet !== null && resultSet[0] !== null) {
            if (resultSet[0].COUNT !== undefined && resultSet[0].COUNT !== null) {
                return resultSet[0].COUNT;
            } else if (resultSet[0].count !== undefined && resultSet[0].count !== null) {
                return resultSet[0].count;
            }
        }
        return 0;
    }

    private async triggerEvent(data: LocationEntityEvent | LocationUpdateEntityEvent) {
        const triggerExtensions = await extensions.loadExtensionModules("Soil-and-Air-Monitoring-System-entities-Location", ["trigger"]);
        triggerExtensions.forEach(triggerExtension => {
            try {
                triggerExtension.trigger(data);
            } catch (error) {
                console.error(error);
            }            
        });
        producer.topic("Soil-and-Air-Monitoring-System-entities-Location").send(JSON.stringify(data));
    }
}
