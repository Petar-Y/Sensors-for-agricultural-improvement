import { query } from "sdk/db";
import { producer } from "sdk/messaging";
import { extensions } from "sdk/extensions";
import { dao as daoApi } from "sdk/db";

export interface MeasurementEntity {
    readonly MeasurementId: number;
    SensorId?: number;
    LocationId?: number;
    Timestamp?: Date;
    Value?: string;
}

export interface MeasurementCreateEntity {
    readonly SensorId?: number;
    readonly LocationId?: number;
    readonly Timestamp?: Date;
    readonly Value?: string;
}

export interface MeasurementUpdateEntity extends MeasurementCreateEntity {
    readonly MeasurementId: number;
}

export interface MeasurementEntityOptions {
    $filter?: {
        equals?: {
            MeasurementId?: number | number[];
            SensorId?: number | number[];
            LocationId?: number | number[];
            Timestamp?: Date | Date[];
            Value?: string | string[];
        };
        notEquals?: {
            MeasurementId?: number | number[];
            SensorId?: number | number[];
            LocationId?: number | number[];
            Timestamp?: Date | Date[];
            Value?: string | string[];
        };
        contains?: {
            MeasurementId?: number;
            SensorId?: number;
            LocationId?: number;
            Timestamp?: Date;
            Value?: string;
        };
        greaterThan?: {
            MeasurementId?: number;
            SensorId?: number;
            LocationId?: number;
            Timestamp?: Date;
            Value?: string;
        };
        greaterThanOrEqual?: {
            MeasurementId?: number;
            SensorId?: number;
            LocationId?: number;
            Timestamp?: Date;
            Value?: string;
        };
        lessThan?: {
            MeasurementId?: number;
            SensorId?: number;
            LocationId?: number;
            Timestamp?: Date;
            Value?: string;
        };
        lessThanOrEqual?: {
            MeasurementId?: number;
            SensorId?: number;
            LocationId?: number;
            Timestamp?: Date;
            Value?: string;
        };
    },
    $select?: (keyof MeasurementEntity)[],
    $sort?: string | (keyof MeasurementEntity)[],
    $order?: 'asc' | 'desc',
    $offset?: number,
    $limit?: number,
}

interface MeasurementEntityEvent {
    readonly operation: 'create' | 'update' | 'delete';
    readonly table: string;
    readonly entity: Partial<MeasurementEntity>;
    readonly key: {
        name: string;
        column: string;
        value: number;
    }
}

interface MeasurementUpdateEntityEvent extends MeasurementEntityEvent {
    readonly previousEntity: MeasurementEntity;
}

export class MeasurementRepository {

    private static readonly DEFINITION = {
        table: "MEASUREMENT",
        properties: [
            {
                name: "MeasurementId",
                column: "MEASUREMENT_MEASUREMENTID",
                type: "INTEGER",
                id: true,
                autoIncrement: true,
            },
            {
                name: "SensorId",
                column: "MEASUREMENT_SENSORID",
                type: "INTEGER",
            },
            {
                name: "LocationId",
                column: "MEASUREMENT_LOCATIONID",
                type: "INTEGER",
            },
            {
                name: "Timestamp",
                column: "MEASUREMENT_TIMESTAMP",
                type: "TIMESTAMP",
            },
            {
                name: "Value",
                column: "MEASUREMENT_VALUE",
                type: "VARCHAR",
            }
        ]
    };

    private readonly dao;

    constructor(dataSource = "DefaultDB") {
        this.dao = daoApi.create(MeasurementRepository.DEFINITION, null, dataSource);
    }

    public findAll(options?: MeasurementEntityOptions): MeasurementEntity[] {
        return this.dao.list(options);
    }

    public findById(id: number): MeasurementEntity | undefined {
        const entity = this.dao.find(id);
        return entity ?? undefined;
    }

    public create(entity: MeasurementCreateEntity): number {
        const id = this.dao.insert(entity);
        this.triggerEvent({
            operation: "create",
            table: "MEASUREMENT",
            entity: entity,
            key: {
                name: "MeasurementId",
                column: "MEASUREMENT_MEASUREMENTID",
                value: id
            }
        });
        return id;
    }

    public update(entity: MeasurementUpdateEntity): void {
        const previousEntity = this.findById(entity.Id);
        this.dao.update(entity);
        this.triggerEvent({
            operation: "update",
            table: "MEASUREMENT",
            entity: entity,
            previousEntity: previousEntity,
            key: {
                name: "MeasurementId",
                column: "MEASUREMENT_MEASUREMENTID",
                value: entity.MeasurementId
            }
        });
    }

    public upsert(entity: MeasurementCreateEntity | MeasurementUpdateEntity): number {
        const id = (entity as MeasurementUpdateEntity).MeasurementId;
        if (!id) {
            return this.create(entity);
        }

        const existingEntity = this.findById(id);
        if (existingEntity) {
            this.update(entity as MeasurementUpdateEntity);
            return id;
        } else {
            return this.create(entity);
        }
    }

    public deleteById(id: number): void {
        const entity = this.dao.find(id);
        this.dao.remove(id);
        this.triggerEvent({
            operation: "delete",
            table: "MEASUREMENT",
            entity: entity,
            key: {
                name: "MeasurementId",
                column: "MEASUREMENT_MEASUREMENTID",
                value: id
            }
        });
    }

    public count(options?: MeasurementEntityOptions): number {
        return this.dao.count(options);
    }

    public customDataCount(): number {
        const resultSet = query.execute('SELECT COUNT(*) AS COUNT FROM "MEASUREMENT"');
        if (resultSet !== null && resultSet[0] !== null) {
            if (resultSet[0].COUNT !== undefined && resultSet[0].COUNT !== null) {
                return resultSet[0].COUNT;
            } else if (resultSet[0].count !== undefined && resultSet[0].count !== null) {
                return resultSet[0].count;
            }
        }
        return 0;
    }

    private async triggerEvent(data: MeasurementEntityEvent | MeasurementUpdateEntityEvent) {
        const triggerExtensions = await extensions.loadExtensionModules("Soil-and-Air-Monitoring-System-entities-Measurement", ["trigger"]);
        triggerExtensions.forEach(triggerExtension => {
            try {
                triggerExtension.trigger(data);
            } catch (error) {
                console.error(error);
            }            
        });
        producer.topic("Soil-and-Air-Monitoring-System-entities-Measurement").send(JSON.stringify(data));
    }
}
